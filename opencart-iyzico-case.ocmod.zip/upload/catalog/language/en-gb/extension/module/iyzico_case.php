<?php
$_['error_required'] = '%s bilgisi zorunludur.';