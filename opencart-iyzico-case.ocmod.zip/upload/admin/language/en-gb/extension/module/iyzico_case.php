<?php
$_['heading_title']     = 'Iyzico Case';

$_['text_extension']    = 'Extensions';
$_['text_edit']         = 'Iyzico Case';
$_['text_enabled']		= 'Aktif';
$_['text_disabled']		= 'Pasif';

$_['entry_status']      = 'Eklenti Durumu';
$_['entry_api_key']     = 'API Anahtarı';
$_['entry_secret_key']  = 'Güvenlik Anahtarı';
$_['entry_shape']       = 'Buton Şekli';
$_['entry_color']       = 'Buton Rengi';
$_['entry_tagline']     = 'Buton Etiketi';

$_['error_permission']  = 'Modül düzenlemesi için yetkiniz yoktur!';
$_['success_save']		= 'Modül düzenlemesi başarılı.';

